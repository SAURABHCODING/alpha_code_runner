require_relative 'application'

Rails.application.initialize!
