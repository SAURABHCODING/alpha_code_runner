#!/bin/bash
sudo cron
exec "$@"
