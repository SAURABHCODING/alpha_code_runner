# Group System and Configuration
<!-- include(system_info.md) -->
<!-- include(configuration_info.md) -->