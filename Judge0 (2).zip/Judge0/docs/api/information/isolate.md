## Isolate [/isolate]
## Isolate [GET]
Returns result of [`isolate --version`](https://github.com/ioi/isolate).