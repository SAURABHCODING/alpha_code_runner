require 'rails_helper'

RSpec.describe "Submissions", type: :request do
end
